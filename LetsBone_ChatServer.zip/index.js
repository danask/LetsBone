
var app = require('express')();
var http = require('http').Server(app);
var io = require('socket.io')(http);
var port = process.env.PORT || 3000;

app.get('/', function(req, res){
  res.sendFile(__dirname + '/index.html');
});

// io.on('connection', function(socket){

//   console.log('one user connected (socket id) '+socket.id);

//   socket.on('message', function(msg)
//   {
//     console.log(msg);


//     var sockets = io.sockets.sockets;

//         // for(var sessionID in sockets)
//         // {
//         //     if(sessionID != socket.id)
//         //     {
//         //         console.log('others: ' + sessionID + ', ' + msg);
//         //         io.to(sessionID).emit('message', msg);
//         //     }
//         // }

//     	socket.broadcast.emit('message', msg);
//   });


//  //  socket.on('join', function(userNickname) {

//  //        console.log(userNickname +" : has joined the chat "  );

//  //        socket.broadcast.emit('userjoinedthechat',userNickname +" : has joined the chat ");
//  //    });


// 	// socket.on('messagedetection', (senderNickname,messageContent) => {
       
//  //       //log the message in console 

//  //       console.log(senderNickname+" :" +messageContent)
//  //        //create a message object 
//  //       let  message = {"message":messageContent, "senderNickname":senderNickname}
//  //          // send the message to the client side  
//  //       io.emit('message', message );
     
//  //      });
      
  
//  // 	socket.on('disconnect', function() {
// 	//     console.log( ' user has left ')
// 	//     socket.broadcast.emit("userdisconnect"," user has left ") 
// 	// });

// });


io.on('connection', (socket) => {

console.log('user connected')

socket.on('join', function(userNickname) {

        console.log(userNickname +" : has joined the chat "  );

        socket.broadcast.emit('userjoinedthechat',userNickname +" : has joined the chat ");
    });


socket.on('messagedetection', (senderNickname,messageContent) => {
       
       //log the message in console 

       console.log(senderNickname+" :" +messageContent)
        //create a message object 
       let  message = {"message":messageContent, "senderNickname":senderNickname}
          // send the message to the client side  
       io.emit('message', message );
     
      });
      
  
 socket.on('disconnect', function() {
    console.log( ' user has left ')
    socket.broadcast.emit("userdisconnect"," user has left ") 

});



});



http.listen(port, function(){
  console.log('listening on *:' + port);
});

// var app = require('express')();
// var http = require('http').Server(app);
// var io = require('socket.io')(http);
// app.get('/',function(req,res){
//     res.sendFile(__dirname+'/index.html');
// })
// io.on('connection',function(socket){
//     console.log('one user connected '+socket.id);


//     socket.on('message', function(data){
        
//         console.log(data);
//         io.emit('message', data);

//         var sockets = io.sockets.sockets;

//         console.log(sockets);

//         // commented
//         Object.keys(sockets).forEach(function(sock){
//             if(sock.id != socket.id)
//             {
//                 sock.emit('message',{message:data});
//             }
//         })
        

//         // socket.emit('message',{message:data});

//         // for w
//         socket.broadcast.emit('message', data);
//     })
//     socket.on('disconnect',function(){
//         console.log('one user disconnected '+socket.id);
//     })
// })



// http.listen(3000,function(){
//     console.log('server listening on port 3000');
// })
