# android-socket.io-server-demo

1) install node
2) npm install from the root. This will install all the dependencies
3) node index.js - this will start the server
4) to change the port  open index.js and change it in line number 29. Right now it is 3000
