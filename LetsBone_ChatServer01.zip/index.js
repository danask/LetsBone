
var app = require('express')();
var http = require('http').Server(app);
var io = require('socket.io')(http);
var port = process.env.PORT || 3000;

app.get('/', function(req, res){
  res.sendFile(__dirname + '/index.html');
});

io.on('connection', function(socket){

  console.log('one user connected '+socket.id);

  socket.on('message', function(msg)
  {
    console.log(msg);


    var sockets = io.sockets.sockets;

        // commented
        // Object.keys(sockets).forEach(function(sock){
        //     if(sock.id != socket.id)
        //     {
        //         sock.emit('message',{message:msg});
        //     }
        // })


        for(var sessionID in sockets)
        {
            if(sessionID != socket.id)
            {
                console.log(sessionID);
                io.to(sessionID).emit('message', msg);

                // io.sockets.socket(sessionID).emit(msg);
                //io.clients[sessionID].send();
                // sock.emit('message', msg);
            }
        }

        // sockets.forEach(function(sock){
        //     if(sock.id != socket.id)
        //     {
        //         sock.emit('message',{message:msg});
        //     }
        // })

    // socket.broadcast.emit('message', msg);
  });

});

http.listen(port, function(){
  console.log('listening on *:' + port);
});

// var app = require('express')();
// var http = require('http').Server(app);
// var io = require('socket.io')(http);
// app.get('/',function(req,res){
//     res.sendFile(__dirname+'/index.html');
// })
// io.on('connection',function(socket){
//     console.log('one user connected '+socket.id);


//     socket.on('message', function(data){
        
//         console.log(data);
//         io.emit('message', data);

//         var sockets = io.sockets.sockets;

//         console.log(sockets);

//         // commented
//         Object.keys(sockets).forEach(function(sock){
//             if(sock.id != socket.id)
//             {
//                 sock.emit('message',{message:data});
//             }
//         })
        

//         // socket.emit('message',{message:data});

//         // for web
//         socket.broadcast.emit('message', data);
//     })
//     socket.on('disconnect',function(){
//         console.log('one user disconnected '+socket.id);
//     })
// })



// http.listen(3000,function(){
//     console.log('server listening on port 3000');
// })
